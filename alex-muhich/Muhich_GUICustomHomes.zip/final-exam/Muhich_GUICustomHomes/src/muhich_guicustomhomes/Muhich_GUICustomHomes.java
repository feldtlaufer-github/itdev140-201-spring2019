
package muhich_guicustomhomes;

/**
 *
 * @author Alex Jerard Muhich
 */
public class Muhich_GUICustomHomes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MainFrame mainframe = new MainFrame();
        mainframe.setVisible(true);
        
        
    }
    
}
