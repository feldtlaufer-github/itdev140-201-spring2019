
package muhich_indivproject;

/**
 * Controller class
 * @author Alex Jerard Muhich
 */
public class Muhich_IndivProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Startup the app by showing the main view
        new MainFrame().setVisible(true);
    }
    
}
