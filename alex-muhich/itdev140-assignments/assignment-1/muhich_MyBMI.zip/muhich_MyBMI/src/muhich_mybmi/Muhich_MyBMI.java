package muhich_mybmi;

/**
 *
 * @author Alex Jerard Muhich
 */
public class Muhich_MyBMI {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        BMI bmi = new BMI();
    }
    
}
